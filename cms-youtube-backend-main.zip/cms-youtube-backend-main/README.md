# cms-youtube-backend
backend for cms created for youtube.

### go to config folder and create a file
```
config.env
```

### and put these details
```
JWT_SECRET =
MONGODB_URI =
```
